export ST_HOME=/home/synda/sdt
export PATH=$ST_HOME/bin:/usr/local/bin:/bin:/usr/bin
