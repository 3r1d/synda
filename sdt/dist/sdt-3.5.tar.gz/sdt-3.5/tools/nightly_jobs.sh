#!/bin/bash -e
SD_TOOLS=/home/synda/sdt/tools
$SD_TOOLS/backup.sh -d /backup/synda/sdt
